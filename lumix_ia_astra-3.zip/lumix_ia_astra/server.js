const express = require('express');
const OpenAI = require('openai');
const crypto = require('crypto');

const app = express();
const port = process.env.PORT || 3000;
const model = process.env.OPENAI_MODEL || 'gpt-6-astra';
const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
  console.warn('\n[ LUMIX ] OPENAI_API_KEY não configurada. Configure a variável de ambiente antes de iniciar.\n');
}

const client = new OpenAI({ apiKey });
const conversations = new Map();

const instructions = `Você é o Lumix, uma IA de uso geral integrada a um aplicativo.
Responda sempre em português do Brasil, salvo se o usuário pedir outro idioma.
Você pode responder perguntas de matemática, português, história, geografia, ciências, programação, tecnologia e assuntos gerais.
Para perguntas simples, seja curto e direto. Para perguntas complexas, explique de forma clara e organizada.
Em matemática, faça as contas com cuidado e mostre os passos quando isso ajudar.
Não invente fatos. Quando não tiver certeza, deixe isso claro.
Se perguntarem quem criou você, responda exatamente: Fui criado por stevamplayz.
Não diga que você é um conjunto de frases programadas: você é um modelo de IA chamado pelo aplicativo Lumix.`;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(__dirname + '/public'));

app.post('/api/chat', async (req, res) => {
  try {
    if (!apiKey) return res.status(500).json({ reply: 'A chave da IA ainda não foi configurada no servidor.' });

    const message = String(req.body?.message || '').trim();
    const sessionId = String(req.body?.sessionId || '').trim();
    if (!message) return res.status(400).json({ reply: 'Digite uma pergunta.' });

    const sid = sessionId || crypto.randomUUID();
    let conversationId = conversations.get(sid);

    if (!conversationId) {
      const conversation = await client.conversations.create();
      conversationId = conversation.id;
      conversations.set(sid, conversationId);
    }

    const response = await client.responses.create({
      model,
      instructions,
      conversation: conversationId,
      input: [{ role: 'user', content: message }]
    });

    res.json({ reply: response.output_text || 'Não consegui gerar uma resposta.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ reply: 'A IA encontrou um erro ao responder. Tente novamente.' });
  }
});

app.listen(port, () => console.log(`Lumix rodando em http://localhost:${port} usando ${model}`));
