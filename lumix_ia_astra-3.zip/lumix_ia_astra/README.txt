LUMIX — IA REAL (GPT-6 Astra)

Esta versão NÃO usa respostas programadas para perguntas. Cada mensagem é enviada ao modelo da OpenAI pela Responses API.

O modelo padrão é gpt-6-astra, listado pela OpenAI como modelo flagship. Você pode trocar para outro modelo disponível alterando OPENAI_MODEL.

IMPORTANTE: a chave da API é secreta e NÃO deve ser colocada no HTML nem compartilhada no chat.

COMO RODAR
1. Instale Node.js em um computador.
2. Abra um terminal dentro desta pasta.
3. Rode: npm install
4. Defina OPENAI_API_KEY com a chave da conta que vai pagar/autorizar o uso da API.
5. Rode: npm start
6. Abra: http://localhost:3000

No Windows PowerShell, por exemplo:
$env:OPENAI_API_KEY="SUA_CHAVE"
npm start

No macOS/Linux:
export OPENAI_API_KEY="SUA_CHAVE"
npm start

O aplicativo mantém o contexto da conversa enquanto o servidor estiver ligado.

OBSERVAÇÃO: o uso da API pode gerar cobrança. Como você é menor de idade, a configuração da conta, da chave e de qualquer cobrança deve ser feita com um responsável.
